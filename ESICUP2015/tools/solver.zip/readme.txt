Requirements: Java 1.8 or newer is required

Here are some quick instructions on how to use the solver:

Usage: java -jar esicup.jar -r <context> -t <time_limit> -p <path> [options]
   -r <context>    : Runtime context (SHORT or LONG). Default: SHORT.
   -t <time_limit> : Runtime limit in seconds (wall time).
   -p <path>       : Path with the problem file and instances folder.

Options:
   -debug          : When enabled, additional error-checking is executed by the solver.
   -gui            : Activate the visualization tool after the solutions are obtained.
                     If this parameter is used alone, the window with the visualization tool will be opened.
   -log <path>     : When enabled, saves several files in <path> to report the method(s) execution.
   -out <path>     : Additional folder path to save a copy of the solution files.
   -rseed <seed>   : Set the random seed.

Examples:
   java -jar esicup.jar -r SHORT -t 3600 -p data/instancesA
   java -jar esicup.jar -r SHORT -t 3600 -p data/instancesA -gui
   java -jar esicup.jar -gui
